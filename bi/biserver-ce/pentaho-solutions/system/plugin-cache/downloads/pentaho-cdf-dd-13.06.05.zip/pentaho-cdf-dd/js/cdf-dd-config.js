

/* Some configuration parameters for CDF-DD */


cdfddLogEnabled = true;
cdfddLogLevel = 3; // Available: 0 - ERROR, 1 - WARN, 2 - INFO, 3 - DEBUG
$.fn.editable.defaults.placeholder = ' - ';
